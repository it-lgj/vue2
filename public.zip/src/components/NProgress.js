//nprogress
import Nprogress from "nprogress";
//nprogress 的css文件
import "nprogress/nprogress.css";

export default Nprogress;
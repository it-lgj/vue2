//该文件下使用常量声明mutation的事件类型

// 令牌存储
export const UPDATE_TOKEN = "UPDATE_TOKEN";
export const REMOVE_TOKEN = "REMOVE_TOKEN";

export const UPDATE_USERINFO = "UPDATE_USERINFO";
// 历史导航
export const ADD_HISTORY = "ADD_HISTORY";
export const REMOVE_HISTORY = "REMOVE_HISTORY";

//存储面包屑指令
export const SAVE_BREADMENU = "SAVE_BREADMENU";
//菜单合并状态
export const UPDATE_COLLAPSE = "UPDATE_COLLAPSE"

export const UPDATE_DEFAULT = "UPDATE_DEFAULT"
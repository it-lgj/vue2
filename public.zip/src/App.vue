<template>
  <div id="app">
    <!-- 配置一级路由出口 -->
    <router-view></router-view>
  </div>
</template>
<script>
export default {
  name: "App",
};
</script>
<style scoped>

</style>

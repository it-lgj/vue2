<template>
  <div id="Error">404</div>
</template>

<script>
export default {
  name: "Error",
  data() {
    return {};
  },
  mounted() {
  },
};
</script>

<style>
</style>